Mini Market Online POS
ضع الـPublishable key الجديد مكان PASTE_NEW_PUBLISHABLE_KEY_HERE ثم ارفع index.html إلى GitHub.
لا تستخدم Secret/service_role key.
